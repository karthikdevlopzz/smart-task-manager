# Smart Task Dashboard

A React-based task management dashboard with analytics, priority management, and Chart.js visualizations.

## Features
- Priority-based task management (High / Medium / Low)
- Status tracking: To Do, In Progress, Done
- Analytics dashboard with Chart.js (Bar, Doughnut, Line charts)
- Search and filter tasks
- Add / delete / complete tasks
- Overdue detection

## Getting Started

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Build for Production

```bash
npm run build
```

## Deploy to Vercel

1. Push to GitHub
2. Import repo at vercel.com
3. Click Deploy — done!
