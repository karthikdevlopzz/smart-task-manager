import React, { useState } from 'react';
import { MdClose } from 'react-icons/md';

export default function AddTaskModal({ onAdd, onClose }) {
  const [form, setForm] = useState({
    title: '', category: 'Engineering', priority: 'medium',
    status: 'todo', deadline: '',
  });

  const handle = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.title.trim() || !form.deadline) return;
    onAdd({ ...form, id: Date.now(), createdAt: new Date().toISOString().split('T')[0] });
    onClose();
  };

  const inputStyle = {
    width: '100%', padding: '10px 12px',
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 8, color: 'var(--text)',
    fontFamily: 'DM Sans, sans-serif',
    fontSize: 13,
    outline: 'none',
  };

  const labelStyle = { fontSize: 12, color: 'var(--muted)', marginBottom: 4, display: 'block', fontWeight: 500 };

  return (
    <div style={{
      position: 'fixed', inset: 0,
      background: 'rgba(0,0,0,0.7)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 200, backdropFilter: 'blur(4px)',
    }} onClick={onClose}>
      <div style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 16, padding: 28, width: 420,
        boxShadow: '0 24px 60px rgba(0,0,0,0.5)',
      }} onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 18, fontWeight: 700 }}>New Task</h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: 20 }}>
            <MdClose />
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div>
            <label style={labelStyle}>Task Title *</label>
            <input value={form.title} onChange={e => handle('title', e.target.value)}
              placeholder="What needs to be done?" style={inputStyle} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label style={labelStyle}>Category</label>
              <select value={form.category} onChange={e => handle('category', e.target.value)} style={inputStyle}>
                {['Engineering','Design','Marketing','DevOps','Research','Docs','Management'].map(c =>
                  <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Priority</label>
              <select value={form.priority} onChange={e => handle('priority', e.target.value)} style={inputStyle}>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label style={labelStyle}>Status</label>
              <select value={form.status} onChange={e => handle('status', e.target.value)} style={inputStyle}>
                <option value="todo">To Do</option>
                <option value="in-progress">In Progress</option>
                <option value="done">Done</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Deadline *</label>
              <input type="date" value={form.deadline} onChange={e => handle('deadline', e.target.value)} style={inputStyle} />
            </div>
          </div>

          <button onClick={submit} style={{
            width: '100%', padding: '12px',
            background: 'var(--accent)',
            border: 'none', borderRadius: 8,
            color: '#fff', fontFamily: 'Syne, sans-serif',
            fontWeight: 700, fontSize: 14, cursor: 'pointer',
            marginTop: 8,
            boxShadow: '0 4px 20px rgba(124,106,247,0.35)',
          }}>
            Add Task
          </button>
        </div>
      </div>
    </div>
  );
}
