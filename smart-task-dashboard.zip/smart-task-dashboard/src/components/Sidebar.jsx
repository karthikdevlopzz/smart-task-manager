import React from 'react';
import { MdDashboard, MdChecklist, MdAnalytics, MdSettings, MdAdd } from 'react-icons/md';

const navItems = [
  { icon: MdDashboard, label: 'Dashboard', id: 'dashboard' },
  { icon: MdChecklist, label: 'Tasks', id: 'tasks' },
  { icon: MdAnalytics, label: 'Analytics', id: 'analytics' },
  { icon: MdSettings, label: 'Settings', id: 'settings' },
];

export default function Sidebar({ activeView, setActiveView, onAddTask }) {
  return (
    <aside style={{
      width: 72,
      background: 'var(--surface)',
      borderRight: '1px solid var(--border)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '24px 0',
      gap: 8,
      position: 'fixed',
      top: 0, left: 0, bottom: 0,
      zIndex: 100,
    }}>
      <div style={{
        width: 36, height: 36,
        background: 'var(--accent)',
        borderRadius: 10,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'Syne, sans-serif',
        fontWeight: 800,
        fontSize: 16,
        color: '#fff',
        marginBottom: 24,
      }}>S</div>

      {navItems.map(({ icon: Icon, label, id }) => (
        <button key={id} onClick={() => setActiveView(id)} title={label} style={{
          width: 44, height: 44,
          background: activeView === id ? 'rgba(124,106,247,0.15)' : 'transparent',
          border: 'none',
          borderRadius: 12,
          color: activeView === id ? 'var(--accent)' : 'var(--muted)',
          cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 20,
          transition: 'all 0.2s',
        }}>
          <Icon />
        </button>
      ))}

      <div style={{ flex: 1 }} />

      <button onClick={onAddTask} title="Add Task" style={{
        width: 44, height: 44,
        background: 'var(--accent)',
        border: 'none',
        borderRadius: 12,
        color: '#fff',
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 22,
        boxShadow: '0 4px 20px rgba(124,106,247,0.4)',
        transition: 'all 0.2s',
      }}>
        <MdAdd />
      </button>
    </aside>
  );
}
