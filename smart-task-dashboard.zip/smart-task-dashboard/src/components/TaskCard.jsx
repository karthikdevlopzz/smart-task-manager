import React from 'react';
import { MdDelete, MdCheckCircle, MdRadioButtonUnchecked, MdAccessTime } from 'react-icons/md';

const priorityColors = { high: 'var(--high)', medium: 'var(--med)', low: 'var(--low)' };
const statusColors = { done: 'var(--done)', 'in-progress': 'var(--accent)', todo: 'var(--muted)' };

export default function TaskCard({ task, onToggle, onDelete }) {
  const isOverdue = task.status !== 'done' && new Date(task.deadline) < new Date();

  return (
    <div style={{
      background: 'var(--surface2)',
      border: `1px solid ${task.status === 'done' ? 'var(--border)' : 'var(--border)'}`,
      borderLeft: `3px solid ${priorityColors[task.priority]}`,
      borderRadius: 12,
      padding: '14px 16px',
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      transition: 'all 0.2s',
      opacity: task.status === 'done' ? 0.6 : 1,
      cursor: 'default',
    }}
    onMouseEnter={e => e.currentTarget.style.background = '#1e1e28'}
    onMouseLeave={e => e.currentTarget.style.background = 'var(--surface2)'}
    >
      <button onClick={() => onToggle(task.id)} style={{
        background: 'none', border: 'none', cursor: 'pointer',
        color: task.status === 'done' ? 'var(--done)' : 'var(--muted)',
        fontSize: 20, display: 'flex', alignItems: 'center', flexShrink: 0,
        transition: 'color 0.2s',
      }}>
        {task.status === 'done' ? <MdCheckCircle /> : <MdRadioButtonUnchecked />}
      </button>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontFamily: 'Syne, sans-serif',
          fontWeight: 600,
          fontSize: 13,
          textDecoration: task.status === 'done' ? 'line-through' : 'none',
          color: task.status === 'done' ? 'var(--muted)' : 'var(--text)',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>{task.title}</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 4, alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{
            fontSize: 11, padding: '2px 8px',
            background: 'rgba(124,106,247,0.1)',
            color: 'var(--accent)',
            borderRadius: 20,
          }}>{task.category}</span>
          <span style={{
            fontSize: 11, padding: '2px 8px',
            background: `${priorityColors[task.priority]}18`,
            color: priorityColors[task.priority],
            borderRadius: 20,
          }}>{task.priority}</span>
          <span style={{
            fontSize: 11, display: 'flex', alignItems: 'center', gap: 3,
            color: isOverdue ? 'var(--high)' : 'var(--muted)',
          }}>
            <MdAccessTime /> {task.deadline}
            {isOverdue && ' (overdue)'}
          </span>
        </div>
      </div>

      <span style={{
        fontSize: 11, padding: '3px 10px',
        background: `${statusColors[task.status]}18`,
        color: statusColors[task.status],
        borderRadius: 20,
        flexShrink: 0,
      }}>{task.status}</span>

      <button onClick={() => onDelete(task.id)} style={{
        background: 'none', border: 'none', cursor: 'pointer',
        color: 'var(--muted)', fontSize: 16, display: 'flex', alignItems: 'center',
        flexShrink: 0, transition: 'color 0.2s',
      }}
      onMouseEnter={e => e.currentTarget.style.color = 'var(--high)'}
      onMouseLeave={e => e.currentTarget.style.color = 'var(--muted)'}
      >
        <MdDelete />
      </button>
    </div>
  );
}
