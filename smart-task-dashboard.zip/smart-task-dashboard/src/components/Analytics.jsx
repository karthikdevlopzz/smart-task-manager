import React from 'react';
import { Bar, Doughnut, Line } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  ArcElement, PointElement, LineElement, Tooltip, Legend, Filler
} from 'chart.js';
import { weeklyData } from '../data/tasks';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, PointElement, LineElement, Tooltip, Legend, Filler);

const chartDefaults = {
  plugins: { legend: { labels: { color: '#6b6b80', font: { family: 'DM Sans' } } } },
};

export default function Analytics({ tasks }) {
  const done = tasks.filter(t => t.status === 'done').length;
  const inProgress = tasks.filter(t => t.status === 'in-progress').length;
  const todo = tasks.filter(t => t.status === 'todo').length;

  const byCategory = tasks.reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + 1;
    return acc;
  }, {});

  const doughnutData = {
    labels: ['Done', 'In Progress', 'To Do'],
    datasets: [{
      data: [done, inProgress, todo],
      backgroundColor: ['#6a9ff7', '#7c6af7', '#2a2a35'],
      borderColor: ['#6a9ff7', '#7c6af7', '#2a2a35'],
      borderWidth: 1,
    }],
  };

  const barData = {
    labels: Object.keys(byCategory),
    datasets: [{
      label: 'Tasks',
      data: Object.values(byCategory),
      backgroundColor: '#7c6af720',
      borderColor: '#7c6af7',
      borderWidth: 2,
      borderRadius: 6,
    }],
  };

  const lineData = {
    labels: weeklyData.map(d => d.day),
    datasets: [
      {
        label: 'Completed',
        data: weeklyData.map(d => d.completed),
        borderColor: '#6af7c8',
        backgroundColor: '#6af7c815',
        fill: true,
        tension: 0.4,
        pointRadius: 4,
        pointBackgroundColor: '#6af7c8',
      },
      {
        label: 'Added',
        data: weeklyData.map(d => d.added),
        borderColor: '#f76a8a',
        backgroundColor: '#f76a8a10',
        fill: true,
        tension: 0.4,
        pointRadius: 4,
        pointBackgroundColor: '#f76a8a',
      },
    ],
  };

  const gridOpts = {
    color: '#2a2a35',
    drawBorder: false,
  };

  const scaleOpts = {
    ticks: { color: '#6b6b80', font: { family: 'DM Sans' } },
    grid: gridOpts,
  };

  const card = { background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 };
  const title = { fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14, marginBottom: 20, color: 'var(--muted)' };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
      <div style={card}>
        <div style={title}>WEEKLY VELOCITY</div>
        <Line data={lineData} options={{ ...chartDefaults, scales: { x: scaleOpts, y: scaleOpts }, responsive: true, maintainAspectRatio: true }} />
      </div>

      <div style={card}>
        <div style={title}>STATUS BREAKDOWN</div>
        <div style={{ maxWidth: 240, margin: '0 auto' }}>
          <Doughnut data={doughnutData} options={{ ...chartDefaults, cutout: '72%', responsive: true }} />
        </div>
      </div>

      <div style={{ ...card, gridColumn: '1 / -1' }}>
        <div style={title}>TASKS BY CATEGORY</div>
        <Bar data={barData} options={{ ...chartDefaults, scales: { x: scaleOpts, y: scaleOpts }, responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }} height={120} />
      </div>
    </div>
  );
}
