import React, { useState, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import TaskCard from './components/TaskCard';
import AddTaskModal from './components/AddTaskModal';
import Analytics from './components/Analytics';
import { initialTasks } from './data/tasks';
import { MdSearch, MdFilterList, MdTrendingUp, MdCheckCircle, MdAccessTime, MdWarning } from 'react-icons/md';

const FILTERS = ['all', 'todo', 'in-progress', 'done'];
const PRIORITIES = ['all', 'high', 'medium', 'low'];

export default function App() {
  const [tasks, setTasks] = useState(initialTasks);
  const [activeView, setActiveView] = useState('dashboard');
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');

  const stats = useMemo(() => {
    const done = tasks.filter(t => t.status === 'done').length;
    const inProgress = tasks.filter(t => t.status === 'in-progress').length;
    const overdue = tasks.filter(t => t.status !== 'done' && new Date(t.deadline) < new Date()).length;
    const completionRate = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
    return { done, inProgress, overdue, completionRate, total: tasks.length };
  }, [tasks]);

  const filtered = useMemo(() => tasks.filter(t => {
    const matchSearch = t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.category.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || t.status === statusFilter;
    const matchPriority = priorityFilter === 'all' || t.priority === priorityFilter;
    return matchSearch && matchStatus && matchPriority;
  }), [tasks, search, statusFilter, priorityFilter]);

  const toggleTask = id => setTasks(ts => ts.map(t =>
    t.id === id ? { ...t, status: t.status === 'done' ? 'todo' : 'done' } : t
  ));

  const deleteTask = id => setTasks(ts => ts.filter(t => t.id !== id));

  const addTask = task => setTasks(ts => [task, ...ts]);

  const statCards = [
    { label: 'Completion Rate', value: `${stats.completionRate}%`, icon: MdTrendingUp, color: 'var(--accent)' },
    { label: 'Completed', value: stats.done, icon: MdCheckCircle, color: 'var(--done)' },
    { label: 'In Progress', value: stats.inProgress, icon: MdAccessTime, color: 'var(--accent2)' },
    { label: 'Overdue', value: stats.overdue, icon: MdWarning, color: 'var(--high)' },
  ];

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar activeView={activeView} setActiveView={setActiveView} onAddTask={() => setShowModal(true)} />

      <main style={{ marginLeft: 72, flex: 1, padding: 32, maxWidth: 1100 }}>
        {/* Header */}
        <div style={{ marginBottom: 32 }}>
          <h1 style={{
            fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 28,
            background: 'linear-gradient(135deg, #f0f0f8, #7c6af7)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            {activeView === 'dashboard' ? 'Dashboard' : activeView === 'tasks' ? 'All Tasks' : activeView === 'analytics' ? 'Analytics' : 'Settings'}
          </h1>
          <p style={{ color: 'var(--muted)', marginTop: 4, fontSize: 13 }}>
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        {/* Dashboard or Tasks View */}
        {(activeView === 'dashboard' || activeView === 'tasks') && (
          <>
            {/* Stat Cards */}
            {activeView === 'dashboard' && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
                {statCards.map(({ label, value, icon: Icon, color }) => (
                  <div key={label} style={{
                    background: 'var(--surface2)',
                    border: '1px solid var(--border)',
                    borderRadius: 16, padding: '20px 24px',
                    display: 'flex', flexDirection: 'column', gap: 12,
                  }}>
                    <div style={{
                      width: 36, height: 36, borderRadius: 10,
                      background: `${color}20`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      color, fontSize: 18,
                    }}>
                      <Icon />
                    </div>
                    <div>
                      <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 28, color }}>{value}</div>
                      <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>{label}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Search & Filter */}
            <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
              <div style={{
                flex: 1, minWidth: 200,
                display: 'flex', alignItems: 'center', gap: 8,
                background: 'var(--surface2)', border: '1px solid var(--border)',
                borderRadius: 10, padding: '8px 14px',
              }}>
                <MdSearch style={{ color: 'var(--muted)', fontSize: 18 }} />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Search tasks..." style={{
                    background: 'none', border: 'none', outline: 'none',
                    color: 'var(--text)', fontFamily: 'DM Sans, sans-serif',
                    fontSize: 13, flex: 1,
                  }} />
              </div>

              <div style={{ display: 'flex', gap: 8 }}>
                {FILTERS.map(f => (
                  <button key={f} onClick={() => setStatusFilter(f)} style={{
                    padding: '8px 14px',
                    background: statusFilter === f ? 'var(--accent)' : 'var(--surface2)',
                    border: `1px solid ${statusFilter === f ? 'var(--accent)' : 'var(--border)'}`,
                    borderRadius: 8, color: statusFilter === f ? '#fff' : 'var(--muted)',
                    cursor: 'pointer', fontFamily: 'DM Sans, sans-serif', fontSize: 12,
                    fontWeight: 500, textTransform: 'capitalize',
                    transition: 'all 0.15s',
                  }}>{f}</button>
                ))}
              </div>

              <div style={{ display: 'flex', gap: 8 }}>
                {PRIORITIES.map(p => (
                  <button key={p} onClick={() => setPriorityFilter(p)} style={{
                    padding: '8px 14px',
                    background: priorityFilter === p ? 'rgba(247,106,138,0.15)' : 'var(--surface2)',
                    border: `1px solid ${priorityFilter === p ? 'var(--high)' : 'var(--border)'}`,
                    borderRadius: 8, color: priorityFilter === p ? 'var(--high)' : 'var(--muted)',
                    cursor: 'pointer', fontFamily: 'DM Sans, sans-serif', fontSize: 12,
                    fontWeight: 500, textTransform: 'capitalize',
                    transition: 'all 0.15s',
                  }}>{p}</button>
                ))}
              </div>
            </div>

            {/* Task count */}
            <div style={{ color: 'var(--muted)', fontSize: 12, marginBottom: 14 }}>
              Showing <strong style={{ color: 'var(--text)' }}>{filtered.length}</strong> of {tasks.length} tasks
            </div>

            {/* Task List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {filtered.length === 0 ? (
                <div style={{ textAlign: 'center', padding: 60, color: 'var(--muted)' }}>
                  No tasks found. Try adjusting your filters.
                </div>
              ) : filtered.sort((a, b) => {
                const po = { high: 0, medium: 1, low: 2 };
                return po[a.priority] - po[b.priority];
              }).map(task => (
                <TaskCard key={task.id} task={task} onToggle={toggleTask} onDelete={deleteTask} />
              ))}
            </div>
          </>
        )}

        {/* Analytics View */}
        {activeView === 'analytics' && <Analytics tasks={tasks} />}

        {/* Settings View */}
        {activeView === 'settings' && (
          <div style={{
            background: 'var(--surface2)', border: '1px solid var(--border)',
            borderRadius: 16, padding: 32, color: 'var(--muted)', textAlign: 'center',
          }}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 18, fontWeight: 700, color: 'var(--text)', marginBottom: 8 }}>
              Settings
            </div>
            Coming soon — manage preferences and notifications here.
          </div>
        )}
      </main>

      {showModal && <AddTaskModal onAdd={addTask} onClose={() => setShowModal(false)} />}
    </div>
  );
}
