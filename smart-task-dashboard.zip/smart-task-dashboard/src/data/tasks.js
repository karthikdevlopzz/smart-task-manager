export const initialTasks = [
  { id: 1, title: "Design system architecture", category: "Engineering", priority: "high", status: "done", deadline: "2025-04-01", createdAt: "2025-03-20" },
  { id: 2, title: "Write API documentation", category: "Docs", priority: "medium", status: "done", deadline: "2025-04-03", createdAt: "2025-03-21" },
  { id: 3, title: "Fix auth bug in login flow", category: "Engineering", priority: "high", status: "done", deadline: "2025-04-02", createdAt: "2025-03-22" },
  { id: 4, title: "Setup CI/CD pipeline", category: "DevOps", priority: "medium", status: "in-progress", deadline: "2025-04-10", createdAt: "2025-03-25" },
  { id: 5, title: "User interviews for v2", category: "Research", priority: "low", status: "in-progress", deadline: "2025-04-15", createdAt: "2025-03-26" },
  { id: 6, title: "Deploy to production", category: "DevOps", priority: "high", status: "todo", deadline: "2025-04-08", createdAt: "2025-03-27" },
  { id: 7, title: "Write unit tests for core", category: "Engineering", priority: "medium", status: "todo", deadline: "2025-04-12", createdAt: "2025-03-28" },
  { id: 8, title: "Update landing page copy", category: "Marketing", priority: "low", status: "todo", deadline: "2025-04-20", createdAt: "2025-03-29" },
  { id: 9, title: "Conduct code review", category: "Engineering", priority: "medium", status: "done", deadline: "2025-04-04", createdAt: "2025-03-23" },
  { id: 10, title: "Prepare sprint retrospective", category: "Management", priority: "low", status: "done", deadline: "2025-04-05", createdAt: "2025-03-24" },
  { id: 11, title: "Optimize DB queries", category: "Engineering", priority: "high", status: "in-progress", deadline: "2025-04-09", createdAt: "2025-03-30" },
  { id: 12, title: "Design onboarding flow", category: "Design", priority: "medium", status: "todo", deadline: "2025-04-18", createdAt: "2025-03-31" },
];

export const weeklyData = [
  { day: "Mon", completed: 3, added: 4 },
  { day: "Tue", completed: 5, added: 3 },
  { day: "Wed", completed: 2, added: 5 },
  { day: "Thu", completed: 6, added: 2 },
  { day: "Fri", completed: 4, added: 4 },
  { day: "Sat", completed: 7, added: 1 },
  { day: "Sun", completed: 3, added: 2 },
];
